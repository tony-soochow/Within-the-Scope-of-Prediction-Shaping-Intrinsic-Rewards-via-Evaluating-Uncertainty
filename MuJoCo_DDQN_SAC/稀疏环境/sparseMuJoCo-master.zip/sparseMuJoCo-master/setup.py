from setuptools import setup

setup(name='sparseMuJoCo',
              version='1.0.0',
                    install_requires=['gym', 'mujoco-py']
                    ) 
